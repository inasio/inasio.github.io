
In this notebook we will attempt to solve a traveling salesman problem (TSP), that is, find the shortest circuit that visits a list of cities (x,y coordinates). This is a classic computationally hard problem, as the number of operations required to exactly solve the problems scales with the factorial of the number of cities. This means that if finding the exact solution for 10 cities takes 1 second, 15 cities will take 4 days, and 50 will take on the order of $10^{50}$ seconds. There are many heuristics to get good approximations in reasonable time, in this problem we will look at a list of 72 cities (kindly provided by Helmut K.). By some miracle we also happen to know that the optimal shortest tour is around 1340 units long, so we can see how well the algorithms do.

We'll start by loading the cities, further down I'll explain a bit more why it's a good idea to load them as complex variables. For a good overview of several TSP algorithms in very readable python code, take a look at Peter Norvig's blog: https://github.com/norvig/pytudes/blob/master/ipynb/TSP.ipynb 

The specifics of the first SA algorithm (temperature and number of iterations) were also sugested by Helmut K., I used some ideas from Norvig's blog for the improvement heuristic.


```python
a = open("tour.txt")
b = a.readlines()
c = [(complex(*(map(int, x.split())))) for x in b]
```

Let's now plot the 72 cities, maybe we can find an obvious pattern...


```python
import matplotlib.pyplot as plt
plt.figure('cities')
plt.plot([x.real for x in c], [x.imag for x in c],'o')
plt.show()
```


![png](output_3_0.png)


As a starting point let's define the initial tour to follow the order in the cities (and close it by adding the first coordinates at the end)


```python
def plot_tour(tour_coords):
    tour = [x.real for x in tour_coords], [x.imag for x in tour_coords]
    plt.figure('init tour')
    plt.plot(*tour,'-', color='black', linewidth=0.5, alpha=0.5)
    plt.plot(*tour,'o', color='red', alpha=0.5)
    plt.axis('Off')
    plt.show()
init_tour = c + [c[0]]
plot_tour(init_tour)

```


![png](output_5_0.png)


So probably not optimal... Let's now define a function to measure the length of the tour. There are multiple ways to compute the euclidean distance (np.linalg.norm, np.sqrt(np.dot...), and it's worth taking some time to find the fastest one because the majority of the time will be spent here. It turns out that defining the coordinates as complex numbers and using abs(x-y) for the distance between x and y is one order of magnitude faster. Using numpy (complex) arrays wasn't faster than the two other approaches, although if the number of cities was larger it could be worth it. Things could still be faster using cython, and something else to explore could be numba just-in-time compilers (@jit)...


```python
from functools import reduce
import numpy as np
def determine_tour_length(tour):
    '''the tour will be defined by an ordered list of (x,y) coordinates, 
    defining a closed tour (N+1 cities)'''
    d0,d1 = tour[:-1], tour[1:]
    return sum(map(lambda x,y: abs(x-y), d0, d1))
test_tour = [complex(0,0), complex(1,0), complex(1,1), complex(0,1)]
closed_tour = test_tour + [test_tour[0]]
assert(determine_tour_length(closed_tour) == 4)
trivial_tour = np.array(c + [c[0]])
print('tour distance =', determine_tour_length(trivial_tour))
```

    tour distance = 7823.79351309


The initial tour is almost 8000 units long. Let's run a few random tours to see if this is an outlier



```python
for i in range(10):
    tour_order = np.random.permutation(range(72))
    random_tour = [c[x] for x in tour_order]
    closed_random_tour = random_tour + [random_tour[0]]
    print('tour distance =', determine_tour_length(closed_random_tour))
```

    tour distance = 8240.03343306173
    tour distance = 7481.408810067784
    tour distance = 7878.686240353122
    tour distance = 7890.301798688618
    tour distance = 7474.685256025552
    tour distance = 8336.508139513355
    tour distance = 8104.539643734696
    tour distance = 7345.164819937847
    tour distance = 7422.1374968482805
    tour distance = 8354.292474378635


Now we'll do a few Montecarlo updates where we switch two cities in the tour, if it results in a shorter tour we keep it, otherwise reject


```python
from time import time

def determine_tour_length(tour):
    '''the tour will be defined by an ordered list of (x,y) coordinates, 
    defining a closed tour (N+1 cities)'''
    return sum(map(lambda x,y: abs(x-y), tour[:-1], tour[1:]))

t0 = time()
tour_order = list(range(72))
open_tour = [c[x] for x in tour_order]
closed_tour = open_tour + [open_tour[0]]
tour_length = determine_tour_length(closed_tour)
print(tour_length)
for i in range(10000):
    swaps_0, swaps_1 = np.random.randint(0,72,2)
    closed_tour[swaps_0], closed_tour[swaps_1] = closed_tour[swaps_1], closed_tour[swaps_0]
    closed_tour[-1] = closed_tour[0]
    tour_length_temp = determine_tour_length(closed_tour)
    if tour_length_temp < tour_length:
        tour_length = tour_length_temp
        continue
    else:
        closed_tour[swaps_0], closed_tour[swaps_1] = closed_tour[swaps_1], closed_tour[swaps_0]
        closed_tour[-1] = closed_tour[0]
print(tour_length)
print('run time =',time() - t0)        
```

    7823.793513086029
    1653.0250177437795
    run time = 0.19757699966430664


For each Montecarlo update we swap two elements in the tour, and always check that the last city is the same as the first one (in order to have a closed tour).

Each 10,000 updates take around 0.2 seconds; as mentioned earlier I thought numpy arrays things could be faster but that doesn't seem to be the case. Another possibility would be to generate a lookup table with all the distances between pairs of cities, might be worth it if things start to take too long.

As it stands, for the next simulated annealing part, we will do 200 runs, with a linearly increasing number of iterations in each (10K x j, with j in range(1,201)... By the young Gauss theorem, that should take around 0.2 sec * 201 * 100 ~= 1 hour, which doesn't sound too bad (a bit more than Trefethen's 5 second limit unfortunately).

Plotting the updated tour we get the following:


```python
plot_tour(closed_tour)
```


![png](output_13_0.png)


This looks much better than the original tour, but still definitely not optimal. We'll use a simulated annealing algorithm to see if we can improve the tour. We randomly pick to cities and check if swapping their order in the tour decreases the distance. If the difference (new_tour - old_tour) is possitive and small, we check a random variable that depends on the "temperature" of the system, if it's smaller we still do the swap. The temperature is high at first, allowing us to more broadly sample the parameter space and potentially avoid falling in local minima, and we slowly decrease the temperature, making positive energy jumps harder and harder (see the annealing process for softening metals: https://en.wikipedia.org/wiki/Annealing_(metallurgy)


```python
T = 20.01
t0 = time()
tour_order = list(range(72))
open_tour = [c[x] for x in tour_order]
closed_tour = open_tour + [open_tour[0]]
tour_length = determine_tour_length(closed_tour)
optimal_tour = closed_tour[:]
temperatures, tours = [T], [tour_length]
print('initial tour length', tour_length)
for j in range(200):
# for j in range(50):
    T -= 0.1
    temperatures += [T]
    iterations = 10000*j
    for i in range(iterations):
        swaps_0, swaps_1 = np.random.randint(0,72,2)
        closed_tour[swaps_0], closed_tour[swaps_1] = closed_tour[swaps_1], closed_tour[swaps_0]
        closed_tour[-1] = closed_tour[0]
        tour_length_temp = determine_tour_length(closed_tour)
        energy = tour_length_temp - tour_length
        if energy < 0:
            tour_length = tour_length_temp
            optimal_tour = closed_tour[:]
            continue
        elif energy >= 0:
            if np.random.random() < np.exp(-energy/T):
                continue
            else:
                closed_tour[swaps_0], closed_tour[swaps_1] = closed_tour[swaps_1], closed_tour[swaps_0]
                closed_tour[-1] = closed_tour[0]
    if tour_length < tours[-1]:
        print('iteration ',j, 'tour length =',tour_length)
    tours += [tour_length]
    closed_tour = optimal_tour[:]

print(tour_length)
print('run time =',(time() - t0)/60, 'minutes')
```

    initial tour length 7823.793513086029
    iteration  1 tour length = 2495.309072338558
    iteration  2 tour length = 2219.613547863588
    iteration  3 tour length = 1911.7195175487811
    iteration  4 tour length = 1901.5953748220106
    iteration  5 tour length = 1843.6748296072683
    iteration  7 tour length = 1832.1679992832576
    iteration  9 tour length = 1824.7575151407534
    iteration  11 tour length = 1820.96842224137
    iteration  12 tour length = 1813.8497053677947
    iteration  13 tour length = 1812.1449160570307
    iteration  15 tour length = 1767.6409049762383
    iteration  17 tour length = 1760.9280740000577
    iteration  18 tour length = 1743.8142248718234
    iteration  21 tour length = 1728.674575296528
    iteration  22 tour length = 1726.6195250428468
    iteration  26 tour length = 1714.661542947305
    iteration  31 tour length = 1708.9956611335044
    iteration  33 tour length = 1707.515804515499
    iteration  39 tour length = 1706.9415675804748
    iteration  51 tour length = 1706.6519026771186
    iteration  54 tour length = 1703.0802143351816
    iteration  55 tour length = 1702.8534177767444
    iteration  64 tour length = 1702.7900167379973
    iteration  65 tour length = 1701.8012159117093
    iteration  66 tour length = 1700.5552295084685
    iteration  74 tour length = 1674.8513366368998
    iteration  75 tour length = 1666.2368445905327
    iteration  76 tour length = 1654.1458584594707
    iteration  80 tour length = 1644.7919631030636
    iteration  82 tour length = 1641.636756634498
    iteration  84 tour length = 1638.9314536369616
    iteration  85 tour length = 1631.8740677310877
    iteration  88 tour length = 1631.1434691444572
    iteration  94 tour length = 1622.085389167282
    iteration  95 tour length = 1620.1844695189172
    iteration  96 tour length = 1613.89740923688
    iteration  99 tour length = 1613.6706126784431
    iteration  106 tour length = 1609.5460964152983
    iteration  111 tour length = 1606.4613196262405
    iteration  121 tour length = 1604.5144063231676
    iteration  122 tour length = 1599.4863421848636
    iteration  133 tour length = 1599.2543695796626
    iteration  139 tour length = 1598.008383176422
    iteration  171 tour length = 1581.1594902621505
    iteration  175 tour length = 1566.6682845581818
    1566.6682845581818
    run time = 79.01413089831671 minutes



```python
plot_tour(closed_tour)
plt.figure('tour length vs temperature')
plt.plot(temperatures[2:], tours[2:])
plt.xlabel('SA temperature')
plt.ylabel('Tour length')
plt.show()
```


![png](output_16_0.png)



![png](output_16_1.png)


The tour is clearly not optimal, an optimal tour will have no crossings. In order to try to fix the crossings we will reverse parts of the tour and see if this results in a shorter tour. Most of the crossings seem to be from long sections, so we'll do the checks from longer to shorter segments


```python
t0 = time()
for length in reversed(range(2, 72)):
    for start in range(0, 72 - length + 1):
        closed_tour = closed_tour[:start] + closed_tour[start:start+length][::-1] + closed_tour[start+length:]
        closed_tour[-1] = closed_tour[0]
        tour_length_temp = determine_tour_length(closed_tour)
        if tour_length_temp < tour_length:
            tour_length = tour_length_temp
        else:
            closed_tour = closed_tour[:start] + closed_tour[start:start+length][::-1] + closed_tour[start+length:]
            closed_tour[-1] = closed_tour[0]
print('improve tour time =', time() - t0)
```

    improve tour time = 0.04706597328186035



```python
print(tour_length)
plot_tour(closed_tour)
```

    1496.6602001880499



![png](output_19_1.png)


This seems to work pretty well, and it takes less than a tenth of a second, so perhaps we could add this at the end of each temperature update in the SA algorithm. This tour is still clearly not optimal.

For the next step, we'll run again the SA algorithm, but now we'll add one step of the remove crossings algorithm at each temperature change, also starting from the initial unoptimized state. 

It turns out that convergence is much faster than the pure SA algorithm, most of the runs arrived at the final state in 5 iterations or less, often to a tour that was more optimal than the one we did above with pure SA. To take advantage of this, we'll do multiple parallel runs of 10 SA steps with the remove_crossings heuristic. One thing that I noticed after a while is that it's very important to start from a random tour ordering.


```python
def remove_crossings(closed_tour):
    tour_length = determine_tour_length(closed_tour)
    for length in reversed(range(2, 72)):
        for start in range(0, 72 - length + 1):
            closed_tour = closed_tour[:start] + closed_tour[start:start+length][::-1] + closed_tour[start+length:]
            closed_tour[-1] = closed_tour[0]
            tour_length_temp = determine_tour_length(closed_tour)
            if tour_length_temp < tour_length:
                tour_length = tour_length_temp
            else:
                closed_tour = closed_tour[:start] + closed_tour[start:start+length][::-1] + closed_tour[start+length:]
                closed_tour[-1] = closed_tour[0]
    return closed_tour

def simulated_annealing_step(optimal_tour, T, iterations):
    closed_tour = optimal_tour[:]
    tour_length = determine_tour_length(closed_tour)
    for i in range(iterations):
        swaps_0, swaps_1 = np.random.randint(0,72,2)
        closed_tour[swaps_0], closed_tour[swaps_1] = closed_tour[swaps_1], closed_tour[swaps_0]
        closed_tour[-1] = closed_tour[0]
        tour_length_temp = determine_tour_length(closed_tour)
        energy = tour_length_temp - tour_length
        if energy < 0:
            tour_length = tour_length_temp
            optimal_tour = closed_tour[:]
            continue
        elif energy >= 0:
            if np.random.random() < np.exp(-energy/T):
                continue
            else:
                closed_tour[swaps_0], closed_tour[swaps_1] = closed_tour[swaps_1], closed_tour[swaps_0]
                closed_tour[-1] = closed_tour[0]
    return optimal_tour
    
tour_order = np.random.permutation(range(72))
open_tour = [c[x] for x in tour_order]
closed_tour = open_tour + [open_tour[0]]
tour_length = determine_tour_length(closed_tour)
# print('initial tour length', tour_length)
optimal_tour = closed_tour[:]
super_optimal_tour = optimal_tour[:]
super_tour_length = tour_length
for k in range(500):
    t0 = time()
    T = 20.01
    tour_order = np.random.permutation(range(72))
    open_tour = [c[x] for x in tour_order]
    closed_tour = open_tour + [open_tour[0]]
    tour_length = determine_tour_length(closed_tour)
    optimal_tour = closed_tour[:]
    temperatures, tours = [T], [tour_length]
    print('initial tour length', tour_length)
#     for j in range(200):
    for j in range(10):
#         T -= 0.1
        T -= 2
        iterations = 10000*j
        optimal_tour = simulated_annealing_step(optimal_tour, T, iterations)
        tour_length = determine_tour_length(optimal_tour)
#         if tour_length < tours[-1]:
#             print('iteration ',j, 'tour length =',tour_length)
        tours += [tour_length]
        temperatures += [T]
        optimal_tour = remove_crossings(optimal_tour)
        tour_length = determine_tour_length(optimal_tour)
#         print('iteration ', k, j,'tour length updated =',tour_length)
        if tour_length < super_tour_length:
            super_optimal_tour = optimal_tour[:]
            super_tour_length = tour_length

    print(k, tour_length, 'run time =',(time() - t0), 'seconds')
    
```

    initial tour length 8551.692347136464
    0 1435.7447812267228 run time = 9.045387983322144 seconds
    initial tour length 7704.713421412914
    1 1432.858860749385 run time = 9.200761795043945 seconds
    initial tour length 7907.334039081648
    2 1398.1063446226055 run time = 9.118589878082275 seconds
    initial tour length 7029.313246558949
    3 1443.0906302888995 run time = 9.217384099960327 seconds
    initial tour length 7511.179633288302
    4 1383.3072084844384 run time = 9.176986932754517 seconds
    initial tour length 8203.18026431208
    5 1510.6573874251653 run time = 9.241087913513184 seconds
    initial tour length 7553.449316131998
    6 1464.631252551504 run time = 9.19437289237976 seconds
    initial tour length 7969.338561716284
    7 1406.977598468712 run time = 9.249701023101807 seconds
    initial tour length 8419.129326536518
    8 1384.0255223890845 run time = 9.029903888702393 seconds
    initial tour length 7704.925458242363
    9 1425.2779611905332 run time = 9.074558973312378 seconds
    initial tour length 8017.01470761087
    10 1434.4083904421616 run time = 9.079636096954346 seconds
    initial tour length 8252.642123069321
    11 1470.0584990821642 run time = 9.188015222549438 seconds
    initial tour length 8276.446531603135
    12 1372.2768350352133 run time = 9.102606058120728 seconds
    initial tour length 8041.919428391718
    13 1478.3440613883824 run time = 9.045632123947144 seconds
    initial tour length 7953.309886925944
    14 1410.2372941747897 run time = 9.171223163604736 seconds
    initial tour length 7390.336736003808
    15 1422.413046284599 run time = 9.123570919036865 seconds
    initial tour length 8536.667893539414
    16 1403.1780787063478 run time = 9.100500106811523 seconds
    initial tour length 7738.834820321516
    17 1456.8050957502803 run time = 9.102956056594849 seconds
    initial tour length 7924.748921744654
    18 1445.2990211219299 run time = 9.114205837249756 seconds
    initial tour length 7766.4883473656255
    19 1392.1352472182928 run time = 9.0763521194458 seconds
    initial tour length 7879.533864625743
    20 1461.3933476661382 run time = 9.091624021530151 seconds
    initial tour length 7860.813675478175
    21 1443.7315723431998 run time = 9.012842893600464 seconds
    initial tour length 7459.862423025809
    22 1481.6836065438642 run time = 9.08668327331543 seconds
    initial tour length 8222.919781878352
    23 1452.3744150828443 run time = 9.083853006362915 seconds
    initial tour length 8181.299310736113
    24 1408.7269374352861 run time = 9.148631811141968 seconds
    initial tour length 7869.081034063721
    25 1469.0457903592435 run time = 9.059245109558105 seconds
    initial tour length 8017.907786040677
    26 1408.7017617513625 run time = 9.08571171760559 seconds
    initial tour length 8265.09018583747
    27 1348.5010809931346 run time = 9.06122612953186 seconds
    initial tour length 6922.63975070096
    28 1450.6749373897746 run time = 9.019942045211792 seconds
    initial tour length 8132.239511853898
    29 1394.6055349802557 run time = 9.063214778900146 seconds
    initial tour length 8204.423429593146
    30 1415.168478651289 run time = 9.067734003067017 seconds
    initial tour length 7819.801306798065
    31 1372.0061398489875 run time = 9.15882396697998 seconds
    initial tour length 8392.368770211173
    32 1433.726460893069 run time = 9.202368974685669 seconds
    initial tour length 7361.006812294247
    33 1446.4697802874557 run time = 9.214163064956665 seconds
    initial tour length 8036.409807991891
    34 1460.7109819851175 run time = 9.104537725448608 seconds
    initial tour length 7195.946660807272
    35 1416.8183403948171 run time = 9.10071325302124 seconds
    initial tour length 8367.984242215007
    36 1539.8186934368025 run time = 9.292699813842773 seconds
    initial tour length 8174.481003178616
    37 1440.6644616356668 run time = 9.188482999801636 seconds
    initial tour length 7557.428744511341
    38 1367.6538533410032 run time = 9.312281847000122 seconds
    initial tour length 8204.95746319025
    39 1521.6197220093704 run time = 9.216039180755615 seconds
    initial tour length 7927.121383088079
    40 1450.30932164763 run time = 9.107856273651123 seconds
    initial tour length 7889.1530772586175
    41 1389.8964023254282 run time = 9.056640863418579 seconds
    initial tour length 8569.766664594292
    42 1422.3811399221634 run time = 9.134001970291138 seconds
    initial tour length 7615.041589681959
    43 1451.407050115755 run time = 9.094395875930786 seconds
    initial tour length 7662.613939344725
    44 1407.7179525066483 run time = 9.005460262298584 seconds
    initial tour length 8059.951979662275
    45 1438.3626711315244 run time = 9.065615177154541 seconds
    initial tour length 7574.307360308447
    46 1420.4141333983227 run time = 9.038860082626343 seconds
    initial tour length 8015.205776090654
    47 1455.915167539344 run time = 9.039161920547485 seconds
    initial tour length 7700.624822992673
    48 1474.8925776166482 run time = 9.07872200012207 seconds
    initial tour length 7822.44010870422
    49 1528.1186969767243 run time = 9.018211841583252 seconds
    initial tour length 7703.244799028163
    50 1448.4277891589015 run time = 9.047750234603882 seconds
    initial tour length 7681.24078215762
    51 1453.1849131049105 run time = 9.071596145629883 seconds
    initial tour length 7908.840192153774
    52 1416.1623417083704 run time = 9.230867147445679 seconds
    initial tour length 6828.05946690744
    53 1500.3237447824945 run time = 9.183030128479004 seconds
    initial tour length 8200.705654128189
    54 1416.702712267967 run time = 9.082955121994019 seconds
    initial tour length 7474.370135840774
    55 1522.5979064878159 run time = 9.153991222381592 seconds
    initial tour length 7762.625908614557
    56 1435.133900617123 run time = 9.111369132995605 seconds
    initial tour length 7585.592343026983
    57 1434.0527060569734 run time = 9.06990098953247 seconds
    initial tour length 7738.143778166753
    58 1397.8917597014072 run time = 9.330650806427002 seconds
    initial tour length 8028.762699883367
    59 1458.6760490053532 run time = 9.119383096694946 seconds
    initial tour length 8407.594761973023
    60 1371.092828104219 run time = 9.100820302963257 seconds
    initial tour length 7512.699677981201
    61 1403.9699994378564 run time = 9.033741235733032 seconds
    initial tour length 8302.634895253479
    62 1395.1288880992145 run time = 9.20089602470398 seconds
    initial tour length 8122.965964130633
    63 1435.0451223100224 run time = 9.129837036132812 seconds
    initial tour length 8772.681512901181
    64 1421.5864723870777 run time = 9.089741706848145 seconds
    initial tour length 7560.522382389217
    65 1438.1914080531108 run time = 9.19214415550232 seconds
    initial tour length 8150.4961483903
    66 1407.0433932650574 run time = 9.038710117340088 seconds
    initial tour length 7519.578546686095
    67 1377.9094492010975 run time = 9.142385244369507 seconds
    initial tour length 7892.082635548832
    68 1410.4510181568717 run time = 9.1806800365448 seconds
    initial tour length 8333.171301593953
    69 1425.1139231686536 run time = 9.128451108932495 seconds
    initial tour length 7605.6776464323375
    70 1400.3044807974575 run time = 9.023258686065674 seconds
    initial tour length 7797.4796033064795
    71 1431.6131834394068 run time = 9.103283882141113 seconds
    initial tour length 7582.919026631557
    72 1445.5872771254162 run time = 9.12193775177002 seconds
    initial tour length 7722.931729812217
    73 1431.0676095933277 run time = 9.065362930297852 seconds
    initial tour length 8489.044506978033
    74 1404.7681466222034 run time = 9.020158052444458 seconds
    initial tour length 7839.802222273454
    75 1390.871314641809 run time = 9.09197187423706 seconds
    initial tour length 8247.10946347537
    76 1468.4177900344393 run time = 9.16022801399231 seconds
    initial tour length 7620.4640770850265
    77 1447.4730722228685 run time = 9.132988929748535 seconds
    initial tour length 7915.29615715432
    78 1382.9504530741533 run time = 9.244008779525757 seconds
    initial tour length 7967.551990502858
    79 1498.8546102497055 run time = 9.220579862594604 seconds
    initial tour length 7738.09111290959
    80 1459.3821351005859 run time = 9.033880233764648 seconds
    initial tour length 7987.935540264014
    81 1397.5017519031378 run time = 9.077314138412476 seconds
    initial tour length 7933.305893165876
    82 1394.4673621871038 run time = 9.134366989135742 seconds
    initial tour length 8238.16151839743
    83 1405.5738874941228 run time = 9.152640104293823 seconds
    initial tour length 7646.625693553261
    84 1468.834897376637 run time = 9.136549234390259 seconds
    initial tour length 7631.641798804406
    85 1386.1281395525814 run time = 9.076143026351929 seconds
    initial tour length 7603.331540583559
    86 1428.5300096882918 run time = 9.091125965118408 seconds
    initial tour length 7889.911187584469
    87 1497.9892008706793 run time = 9.020940065383911 seconds
    initial tour length 7775.612477725587
    88 1395.851257645968 run time = 9.054143905639648 seconds
    initial tour length 7878.164357567615
    89 1420.4699870459644 run time = 9.057345151901245 seconds
    initial tour length 7963.025657758183
    90 1416.7212101013113 run time = 9.15691590309143 seconds
    initial tour length 7712.784701555569
    91 1389.6713009487196 run time = 9.141834020614624 seconds
    initial tour length 7684.9313157285615
    92 1408.3429967613756 run time = 9.198521852493286 seconds
    initial tour length 7570.653177489313
    93 1463.0698488321468 run time = 9.215640783309937 seconds
    initial tour length 7710.562113017733
    94 1419.6692673844595 run time = 9.0729238986969 seconds
    initial tour length 7744.646674689872
    95 1417.7134258270419 run time = 9.07236099243164 seconds
    initial tour length 8184.20987846765
    96 1533.940624920192 run time = 9.263776063919067 seconds
    initial tour length 7537.826896827345
    97 1453.4864790246477 run time = 9.051183938980103 seconds
    initial tour length 8048.086275484894
    98 1445.3046496805616 run time = 9.071887731552124 seconds
    initial tour length 8208.78168159065
    99 1456.096897421134 run time = 9.070549964904785 seconds
    initial tour length 8213.67579789988
    100 1420.5564449391632 run time = 9.001749038696289 seconds
    initial tour length 7871.146511188458
    101 1381.429909474791 run time = 8.978593111038208 seconds
    initial tour length 7992.212074290325
    102 1438.7250447602153 run time = 9.283630132675171 seconds
    initial tour length 7915.142910039232
    103 1471.34566464662 run time = 9.197654008865356 seconds
    initial tour length 7749.599922158924
    104 1439.6900247331816 run time = 9.044508934020996 seconds
    initial tour length 7190.904884536461
    105 1405.549955805405 run time = 9.13020372390747 seconds
    initial tour length 7570.620059164046
    106 1525.2397134562582 run time = 9.088769674301147 seconds
    initial tour length 7395.541155244732
    107 1404.986336946681 run time = 9.181710958480835 seconds
    initial tour length 7971.353765612645
    108 1397.5167267572092 run time = 9.101407051086426 seconds
    initial tour length 7262.488141130146
    109 1424.2889108290094 run time = 9.019641876220703 seconds
    initial tour length 8538.244128712366
    110 1397.4024584183571 run time = 9.07627010345459 seconds
    initial tour length 7212.341797319615
    111 1403.7214034729266 run time = 9.005092144012451 seconds
    initial tour length 7981.693600357796
    112 1466.3793495148739 run time = 9.0504629611969 seconds
    initial tour length 8147.284546725647
    113 1427.0690337942215 run time = 9.128490924835205 seconds
    initial tour length 7774.991939425117
    114 1457.9677461213807 run time = 9.278035879135132 seconds
    initial tour length 7583.834868681216
    115 1443.1711145033075 run time = 9.12978196144104 seconds
    initial tour length 7480.387521444026
    116 1396.2367046034203 run time = 9.07559084892273 seconds
    initial tour length 8170.186599390935
    117 1406.5021278816373 run time = 9.149537801742554 seconds
    initial tour length 7674.254256347111
    118 1388.597225872492 run time = 9.182476997375488 seconds
    initial tour length 7725.444456714663
    119 1462.5418420770093 run time = 9.125026226043701 seconds
    initial tour length 8585.547738408315
    120 1413.9875568524221 run time = 9.034284830093384 seconds
    initial tour length 7805.4805922805635
    121 1405.993307726606 run time = 9.1322340965271 seconds
    initial tour length 7532.370544501443
    122 1420.8190840112616 run time = 9.166944980621338 seconds
    initial tour length 8154.263731979164
    123 1458.5505033013028 run time = 9.077911138534546 seconds
    initial tour length 7264.026193426763
    124 1389.5489053805838 run time = 9.014264106750488 seconds
    initial tour length 7426.796877346271
    125 1521.0430064153911 run time = 9.145503997802734 seconds
    initial tour length 7456.2458577569805
    126 1447.2562147635438 run time = 9.159378290176392 seconds
    initial tour length 8022.562091405174
    127 1400.5320623675273 run time = 9.168710947036743 seconds
    initial tour length 8232.026428558453
    128 1409.318726341796 run time = 9.0939359664917 seconds
    initial tour length 7898.148022741516
    129 1457.477805371021 run time = 9.009602069854736 seconds
    initial tour length 8090.3784614838805
    130 1445.7758570092367 run time = 9.134245872497559 seconds
    initial tour length 8004.9781472014365
    131 1455.610832774016 run time = 9.205985069274902 seconds
    initial tour length 7108.578293353267
    132 1389.5542720279439 run time = 9.03573203086853 seconds
    initial tour length 7852.614521430135
    133 1385.9757479547054 run time = 9.030521154403687 seconds
    initial tour length 8074.112761958425
    134 1420.2154039261516 run time = 9.059817790985107 seconds
    initial tour length 8036.690286495385
    135 1438.5189958644019 run time = 9.021703004837036 seconds
    initial tour length 8066.455104346157
    136 1397.8344153499115 run time = 9.154173851013184 seconds
    initial tour length 7336.563608049132
    137 1447.6154931349417 run time = 9.06598687171936 seconds
    initial tour length 7256.907376635841
    138 1427.8671033642606 run time = 9.117681980133057 seconds
    initial tour length 7155.076378712935
    139 1410.9905423912112 run time = 9.017892837524414 seconds
    initial tour length 8122.663611581341
    140 1424.1837930052473 run time = 9.143189907073975 seconds
    initial tour length 7828.785920379208
    141 1417.931187844529 run time = 8.975487232208252 seconds
    initial tour length 7976.076153949037
    142 1487.7417195925746 run time = 9.09611988067627 seconds
    initial tour length 7672.279431615322
    143 1385.3914588277867 run time = 9.141613960266113 seconds
    initial tour length 7637.106836641117
    144 1486.0089749796105 run time = 9.161409854888916 seconds
    initial tour length 7257.694742221136
    145 1392.272174782928 run time = 9.083307981491089 seconds
    initial tour length 8295.554878516221
    146 1420.082989139864 run time = 9.109163045883179 seconds
    initial tour length 8037.092462194945
    147 1461.736685556726 run time = 9.155164957046509 seconds
    initial tour length 7556.144752007386
    148 1407.4904435752999 run time = 8.979877948760986 seconds
    initial tour length 7062.876634150749
    149 1405.0428323740693 run time = 9.170155048370361 seconds
    initial tour length 7558.923955600413
    150 1476.8332993423126 run time = 9.113393068313599 seconds
    initial tour length 7990.719148923167
    151 1434.1114273998376 run time = 9.059019804000854 seconds
    initial tour length 7381.253159280754
    152 1409.293068182233 run time = 9.151694059371948 seconds
    initial tour length 7485.660257839329
    153 1450.4039108279565 run time = 9.127633810043335 seconds
    initial tour length 7681.761737410514
    154 1452.7046899257539 run time = 9.001713037490845 seconds
    initial tour length 7892.3655128325045
    155 1407.5473673261797 run time = 9.089982271194458 seconds
    initial tour length 7875.110481619035
    156 1415.92268474383 run time = 9.166235208511353 seconds
    initial tour length 7608.554427709295
    157 1437.2825742930372 run time = 9.09480905532837 seconds
    initial tour length 7878.3321438723
    158 1412.4884038955956 run time = 9.203988075256348 seconds
    initial tour length 7873.8691023158835
    159 1522.655989409988 run time = 9.16057538986206 seconds
    initial tour length 8133.621939231917
    160 1448.775109857535 run time = 9.157011032104492 seconds
    initial tour length 7974.000302698505
    161 1442.4712244293328 run time = 9.026501893997192 seconds
    initial tour length 7433.536624255224
    162 1421.7615191563275 run time = 9.042248964309692 seconds
    initial tour length 7855.9717032687995
    163 1403.8516667111653 run time = 9.201019287109375 seconds
    initial tour length 8217.709648526212
    164 1393.2926854581833 run time = 9.130972862243652 seconds
    initial tour length 7873.812464611128
    165 1393.2614601006217 run time = 9.074419021606445 seconds
    initial tour length 7874.946475460453
    166 1430.4780149190594 run time = 9.07051420211792 seconds
    initial tour length 8133.311322065707
    167 1415.5738911846533 run time = 9.020406007766724 seconds
    initial tour length 8106.904360011487
    168 1463.1269651131445 run time = 9.05826997756958 seconds
    initial tour length 7620.250923953641
    169 1384.7566086300808 run time = 9.076061964035034 seconds
    initial tour length 7132.33744190659
    170 1443.2107187819743 run time = 9.123175144195557 seconds
    initial tour length 7622.942424205442
    171 1424.6956810584543 run time = 9.1582190990448 seconds
    initial tour length 7603.578277921305
    172 1383.9056615371428 run time = 9.119594097137451 seconds
    initial tour length 7763.548603262715
    173 1447.4185632036279 run time = 9.021157264709473 seconds
    initial tour length 7701.649775981588
    174 1403.1899328817751 run time = 9.106787919998169 seconds
    initial tour length 7657.993726718114
    175 1499.4016755526745 run time = 9.020417928695679 seconds
    initial tour length 7488.904814866578
    176 1449.3325422753232 run time = 9.198202133178711 seconds
    initial tour length 8098.752957342856
    177 1377.4853496496942 run time = 9.197222709655762 seconds
    initial tour length 7981.804368622155
    178 1518.2321218640327 run time = 9.075122117996216 seconds
    initial tour length 7826.54288347464
    179 1418.3975068351099 run time = 9.06820297241211 seconds
    initial tour length 8169.151991376798
    180 1392.0846165327619 run time = 9.136689186096191 seconds
    initial tour length 8019.525000525632
    181 1423.4682637776561 run time = 9.086874961853027 seconds
    initial tour length 7890.698643669832
    182 1455.3194034990447 run time = 9.01962399482727 seconds
    initial tour length 7716.996529570417
    183 1519.6579648719298 run time = 9.24260139465332 seconds
    initial tour length 7548.705771019586
    184 1436.04014790096 run time = 9.128215074539185 seconds
    initial tour length 7622.235343034842
    185 1464.368806880401 run time = 9.026260137557983 seconds
    initial tour length 8360.809030614517
    186 1394.7871840812063 run time = 9.052740812301636 seconds
    initial tour length 7941.026777054789
    187 1413.94200475008 run time = 9.009097814559937 seconds
    initial tour length 7333.807803377991
    188 1485.3389066630198 run time = 9.095659971237183 seconds
    initial tour length 8161.333546415323
    189 1387.999260212006 run time = 9.086472272872925 seconds
    initial tour length 8224.927951014055
    190 1465.1060281199982 run time = 9.08522081375122 seconds
    initial tour length 7991.46700032335
    191 1442.0504513442022 run time = 9.046864986419678 seconds
    initial tour length 7684.628541299385
    192 1463.7690321431166 run time = 9.259849071502686 seconds
    initial tour length 7940.091159938329
    193 1437.7307061581248 run time = 9.00093698501587 seconds
    initial tour length 7393.400549675966
    194 1445.2705567891114 run time = 9.127762794494629 seconds
    initial tour length 8117.29435616603
    195 1423.6809540766135 run time = 9.086249113082886 seconds
    initial tour length 7709.986072613071
    196 1429.1525720534964 run time = 9.123740911483765 seconds
    initial tour length 7648.766209377849
    197 1458.6122462715455 run time = 9.030928134918213 seconds
    initial tour length 7787.23000636264
    198 1400.3563225354178 run time = 9.133904933929443 seconds
    initial tour length 8055.161438875446
    199 1416.7993168190253 run time = 9.118165016174316 seconds
    initial tour length 8468.646481925458
    200 1447.9350201611867 run time = 9.083672046661377 seconds
    initial tour length 7957.776667400525
    201 1427.931231611624 run time = 9.089778184890747 seconds
    initial tour length 7516.729778632876
    202 1470.7392957357818 run time = 9.018663167953491 seconds
    initial tour length 7356.276329388284
    203 1432.498832415224 run time = 9.044151067733765 seconds
    initial tour length 7832.608810897021
    204 1486.0411630703766 run time = 9.0466890335083 seconds
    initial tour length 8270.992267082349
    205 1481.1085290790716 run time = 9.044703960418701 seconds
    initial tour length 7396.783768494066
    206 1397.0112721587204 run time = 9.106889009475708 seconds
    initial tour length 7696.728711951587
    207 1380.8584777384522 run time = 9.126887798309326 seconds
    initial tour length 7202.187241653288
    208 1480.2465666666126 run time = 9.015599250793457 seconds
    initial tour length 8182.763186206207
    209 1429.8935662745118 run time = 9.206520795822144 seconds
    initial tour length 7693.093521541535
    210 1395.3157251966365 run time = 9.133243322372437 seconds
    initial tour length 7663.171689929427
    211 1452.240885909636 run time = 9.036418914794922 seconds
    initial tour length 8008.788072235748
    212 1443.1371966945865 run time = 9.155979871749878 seconds
    initial tour length 7794.966857403421
    213 1499.7071172514904 run time = 9.048986673355103 seconds
    initial tour length 7135.944734709137
    214 1410.6546873952138 run time = 9.092323064804077 seconds
    initial tour length 8603.863971732437
    215 1402.9909307154287 run time = 9.090059041976929 seconds
    initial tour length 7638.056372010458
    216 1421.3943124303592 run time = 9.119236707687378 seconds
    initial tour length 7770.804395086815
    217 1424.2383865584095 run time = 9.107702016830444 seconds
    initial tour length 7565.8097726469105
    218 1413.689370661964 run time = 9.221446752548218 seconds
    initial tour length 7313.423513216471
    219 1477.3402014173605 run time = 9.123067140579224 seconds
    initial tour length 8099.904435386647
    220 1477.4878123131268 run time = 9.165412664413452 seconds
    initial tour length 8061.240225673402
    221 1382.453330372333 run time = 9.039015769958496 seconds
    initial tour length 8231.463005951364
    222 1411.8183951478647 run time = 9.118385791778564 seconds
    initial tour length 7874.660512168971
    223 1491.9324220916317 run time = 9.101708173751831 seconds
    initial tour length 7851.461434841108
    224 1396.8310336259997 run time = 9.12743592262268 seconds
    initial tour length 7581.782851755718
    225 1410.5887078829091 run time = 9.107260942459106 seconds
    initial tour length 7958.117905959577
    226 1372.2249780906843 run time = 9.054931163787842 seconds
    initial tour length 7323.951716818396
    227 1484.453293593655 run time = 9.194947957992554 seconds
    initial tour length 8355.194300417656
    228 1405.0946864783643 run time = 9.115686893463135 seconds
    initial tour length 7848.312588760474
    229 1405.4972873681027 run time = 9.0837562084198 seconds
    initial tour length 8096.321080221988
    230 1465.3968722854413 run time = 9.135419845581055 seconds
    initial tour length 8555.537779313849
    231 1481.6571984540462 run time = 9.00751805305481 seconds
    initial tour length 7468.246169202542
    232 1440.460271531613 run time = 9.063992738723755 seconds
    initial tour length 7669.138247419762
    233 1430.0811900000506 run time = 9.111992120742798 seconds
    initial tour length 8439.674651310328
    234 1432.7174025635898 run time = 9.032060146331787 seconds
    initial tour length 7929.772734959878
    235 1434.7245475918016 run time = 9.093905925750732 seconds
    initial tour length 7495.725739312023
    236 1388.6250522918651 run time = 9.230072021484375 seconds
    initial tour length 8051.88342706328
    237 1496.5850669801312 run time = 9.067740201950073 seconds
    initial tour length 7908.31619658398
    238 1506.7865926991171 run time = 9.083693027496338 seconds
    initial tour length 7571.742134224058
    239 1398.8828163151745 run time = 9.132958889007568 seconds
    initial tour length 7762.141956883072
    240 1415.3751638101992 run time = 9.12122893333435 seconds
    initial tour length 7890.7038147645735
    241 1423.1981689202544 run time = 9.156208038330078 seconds
    initial tour length 6908.826007608625
    242 1543.337786824177 run time = 9.121338129043579 seconds
    initial tour length 8095.17499894837
    243 1378.9205958232828 run time = 9.13011908531189 seconds
    initial tour length 7934.127290704302
    244 1482.4812646231094 run time = 9.034770011901855 seconds
    initial tour length 8107.7487219499535
    245 1531.2564824470521 run time = 9.203389883041382 seconds
    initial tour length 8200.618313294217
    246 1433.4395804501223 run time = 9.163636922836304 seconds
    initial tour length 8113.945585383063
    247 1429.8061694166124 run time = 9.072649955749512 seconds
    initial tour length 8525.926059469833
    248 1400.2230626841308 run time = 9.03387975692749 seconds
    initial tour length 7964.123350523839
    249 1431.2782121355124 run time = 9.142316102981567 seconds
    initial tour length 7604.431452728829
    250 1416.6986876958338 run time = 9.113152980804443 seconds
    initial tour length 7866.911806016221
    251 1374.7210844598012 run time = 9.004327297210693 seconds
    initial tour length 7112.08179593931
    252 1397.6762846430431 run time = 9.175327062606812 seconds
    initial tour length 7856.106022765378
    253 1402.713003595391 run time = 9.090340852737427 seconds
    initial tour length 7598.856242433264
    254 1535.3366866054691 run time = 9.113534927368164 seconds
    initial tour length 7207.110749604093
    255 1384.4017222880082 run time = 9.082581996917725 seconds
    initial tour length 7315.6382167562715
    256 1437.6136062497214 run time = 9.200563907623291 seconds
    initial tour length 7807.289907495407
    257 1446.6447189824419 run time = 9.073215961456299 seconds
    initial tour length 7686.109165807424
    258 1436.2528024422534 run time = 9.184981107711792 seconds
    initial tour length 7860.562739286843
    259 1466.2002264056594 run time = 9.090191841125488 seconds
    initial tour length 7874.625841304229
    260 1490.9326927542465 run time = 9.036426067352295 seconds
    initial tour length 8016.625872821326
    261 1514.7968448327927 run time = 9.064905881881714 seconds
    initial tour length 8074.37827683612
    262 1440.8023166255148 run time = 9.146201133728027 seconds
    initial tour length 7997.855762500307
    263 1416.6041983969099 run time = 9.226922035217285 seconds
    initial tour length 7880.829410483495
    264 1520.465646727862 run time = 9.096059799194336 seconds
    initial tour length 7829.997113575046
    265 1482.9974772699418 run time = 9.006566762924194 seconds
    initial tour length 7591.214178582279
    266 1417.6580331306775 run time = 9.132342100143433 seconds
    initial tour length 7567.526606922522
    267 1411.6292387138844 run time = 9.117458820343018 seconds
    initial tour length 8190.07954649263
    268 1566.0549398153207 run time = 9.088799953460693 seconds
    initial tour length 8322.43370931174
    269 1485.4040159069514 run time = 9.169604063034058 seconds
    initial tour length 8060.316161920259
    270 1434.7915410532667 run time = 9.210984945297241 seconds
    initial tour length 7569.158972842042
    271 1413.3656522627948 run time = 9.057268857955933 seconds
    initial tour length 7127.356189817539
    272 1418.2537726503638 run time = 9.119860887527466 seconds
    initial tour length 7481.665160320038
    273 1415.5244836987304 run time = 9.112319946289062 seconds
    initial tour length 7896.630379482584
    274 1497.4560310504392 run time = 9.033876895904541 seconds
    initial tour length 8423.201462766305
    275 1454.4463573865223 run time = 9.100152254104614 seconds
    initial tour length 8405.704518429922
    276 1437.285352650792 run time = 9.165718078613281 seconds
    initial tour length 7963.624520014718
    277 1366.308239668179 run time = 9.159063816070557 seconds
    initial tour length 8261.96032175056
    278 1412.494060563116 run time = 9.005635023117065 seconds
    initial tour length 7290.980856386072
    279 1419.487982208532 run time = 9.163400888442993 seconds
    initial tour length 7786.827595114397
    280 1460.211273099813 run time = 9.150984048843384 seconds
    initial tour length 7436.915059177464
    281 1466.6352658851772 run time = 9.145128965377808 seconds
    initial tour length 8549.271941802206
    282 1389.2578272640658 run time = 9.023744106292725 seconds
    initial tour length 8388.59157328406
    283 1377.8559795172982 run time = 9.068557024002075 seconds
    initial tour length 7806.778411125067
    284 1447.0863260185508 run time = 9.144069194793701 seconds
    initial tour length 7906.134630513769
    285 1456.4952838417619 run time = 9.022247791290283 seconds
    initial tour length 7896.6295281483735
    286 1418.9409316954086 run time = 9.1005539894104 seconds
    initial tour length 7671.499356363254
    287 1435.0568120231871 run time = 9.017872095108032 seconds
    initial tour length 7999.4284191397155
    288 1466.643628062822 run time = 9.023936033248901 seconds
    initial tour length 6925.068163241938
    289 1382.6478841088826 run time = 9.127763986587524 seconds
    initial tour length 7370.752057998056
    290 1405.7559216295892 run time = 9.140380859375 seconds
    initial tour length 7570.902730723689
    291 1512.508121013117 run time = 9.177824974060059 seconds
    initial tour length 8104.382359432995
    292 1443.432172681308 run time = 9.068418979644775 seconds
    initial tour length 7957.2008945219095
    293 1451.0415384833304 run time = 9.07057499885559 seconds
    initial tour length 7540.372244752063
    294 1438.059938207759 run time = 9.1272611618042 seconds
    initial tour length 8305.196072715149
    295 1413.674665025944 run time = 9.126297950744629 seconds
    initial tour length 8544.43039617277
    296 1437.524254537592 run time = 8.990503311157227 seconds
    initial tour length 7906.244645475387
    297 1420.4402128953523 run time = 9.14206576347351 seconds
    initial tour length 7690.84545966542
    298 1389.0673575861867 run time = 9.149216890335083 seconds
    initial tour length 8489.741876121347
    299 1400.270415543519 run time = 9.112527847290039 seconds
    initial tour length 8033.978050992562
    300 1472.0980351716105 run time = 9.135732173919678 seconds
    initial tour length 7270.613396977944
    301 1435.2594693171789 run time = 9.068896055221558 seconds
    initial tour length 8087.3536885801395
    302 1421.7822201219647 run time = 9.018492221832275 seconds
    initial tour length 8167.804114240397
    303 1398.072147261995 run time = 9.078792810440063 seconds
    initial tour length 7577.051007839861
    304 1373.7910924864284 run time = 9.117602109909058 seconds
    initial tour length 8009.614438704131
    305 1474.3889544273507 run time = 9.037126779556274 seconds
    initial tour length 7059.477533598996
    306 1421.035451723325 run time = 9.04436707496643 seconds
    initial tour length 7734.205025858709
    307 1428.1045594348327 run time = 8.983907222747803 seconds
    initial tour length 7208.840856731528
    308 1367.6179275602572 run time = 9.083051204681396 seconds
    initial tour length 8374.851365720264
    309 1473.0452037576288 run time = 9.201884031295776 seconds
    initial tour length 7468.928229803789
    310 1352.0117937878779 run time = 9.048336267471313 seconds
    initial tour length 7927.509726934948
    311 1436.6833171867468 run time = 9.091567039489746 seconds
    initial tour length 8083.271080065431
    312 1516.7824149610267 run time = 9.097473859786987 seconds
    initial tour length 7928.430263920129
    313 1409.2395724203695 run time = 9.17960000038147 seconds
    initial tour length 8286.164716230494
    314 1426.6642638869107 run time = 9.055196046829224 seconds
    initial tour length 8265.471289509336
    315 1429.3544457013936 run time = 9.175920009613037 seconds
    initial tour length 8142.072098463243
    316 1400.5877540014076 run time = 9.101258039474487 seconds
    initial tour length 7849.444981735571
    317 1481.5552737052317 run time = 9.127157926559448 seconds
    initial tour length 7962.908068798724
    318 1451.3079124795759 run time = 9.05680799484253 seconds
    initial tour length 7894.248387503272
    319 1439.7992979515805 run time = 9.134974002838135 seconds
    initial tour length 7749.131177894737
    320 1371.627445907654 run time = 9.123113870620728 seconds
    initial tour length 8222.593696088572
    321 1425.7059942533615 run time = 9.065033912658691 seconds
    initial tour length 7978.651883096015
    322 1413.351843815944 run time = 9.066209077835083 seconds
    initial tour length 8228.207112940083
    323 1372.86334207031 run time = 9.088726997375488 seconds
    initial tour length 8052.099449617659
    324 1391.8902403477903 run time = 9.072062969207764 seconds
    initial tour length 7896.8855752057725
    325 1387.4590924361619 run time = 8.991291284561157 seconds
    initial tour length 7488.604260969547
    326 1418.300814741521 run time = 9.113002061843872 seconds
    initial tour length 7561.534727700972
    327 1431.541361865634 run time = 8.959926128387451 seconds
    initial tour length 8560.446314745075
    328 1435.7637619367347 run time = 9.233232259750366 seconds
    initial tour length 7797.750899686999
    329 1445.1096763812502 run time = 9.186411142349243 seconds
    initial tour length 7762.161825479502
    330 1425.2597265570382 run time = 9.439632177352905 seconds
    initial tour length 7097.303592279873
    331 1413.6449647021198 run time = 9.329800128936768 seconds
    initial tour length 7194.171632343596
    332 1348.8456647023347 run time = 9.044443845748901 seconds
    initial tour length 7623.547876020981
    333 1393.7869846003991 run time = 9.104290962219238 seconds
    initial tour length 8238.476229388883
    334 1439.8878166016955 run time = 9.213635683059692 seconds
    initial tour length 8185.995723621258
    335 1447.6594863298267 run time = 9.045276880264282 seconds
    initial tour length 7393.993614179336
    336 1437.8445262907348 run time = 9.032374858856201 seconds
    initial tour length 7626.6427560071825
    337 1411.4867339323907 run time = 9.026994943618774 seconds
    initial tour length 6892.435008059552
    338 1412.8467077062755 run time = 9.077540874481201 seconds
    initial tour length 8106.846015884693
    339 1400.8374934761002 run time = 9.129212856292725 seconds
    initial tour length 7749.337464868537
    340 1355.8975101162296 run time = 9.071156978607178 seconds
    initial tour length 7513.615157426974
    341 1396.452767793078 run time = 9.12982988357544 seconds
    initial tour length 7539.938133721522
    342 1435.9975298243198 run time = 9.138385772705078 seconds
    initial tour length 8131.326202040431
    343 1433.776676448298 run time = 9.067476034164429 seconds
    initial tour length 7900.823707271037
    344 1397.759482560841 run time = 9.108038902282715 seconds
    initial tour length 7498.098513490901
    345 1388.0255350141033 run time = 9.090057849884033 seconds
    initial tour length 7504.277767156138
    346 1431.799208798487 run time = 9.088602066040039 seconds
    initial tour length 8227.903152620045
    347 1423.2324901996149 run time = 9.129480123519897 seconds
    initial tour length 6745.727945475225
    348 1403.4333718050598 run time = 9.107533931732178 seconds
    initial tour length 8282.653711842355
    349 1394.819125820635 run time = 9.024813890457153 seconds
    initial tour length 8213.03874909429
    350 1450.628864652101 run time = 9.026838064193726 seconds
    initial tour length 7899.856760325236
    351 1367.3263615583994 run time = 9.196324825286865 seconds
    initial tour length 7864.839567625447
    352 1443.6802702965506 run time = 9.12899398803711 seconds
    initial tour length 7048.534184537056
    353 1411.4606146919418 run time = 9.057615041732788 seconds
    initial tour length 7669.3933682138995
    354 1488.6253670977865 run time = 9.138558864593506 seconds
    initial tour length 7412.14813818752
    355 1412.692245867581 run time = 9.10627293586731 seconds
    initial tour length 7600.022078502842
    356 1442.2855654956616 run time = 9.0664541721344 seconds
    initial tour length 7566.237915779189
    357 1481.8069702233956 run time = 9.065386056900024 seconds
    initial tour length 7947.232029454204
    358 1422.2143525326358 run time = 9.106980085372925 seconds
    initial tour length 7789.328353391286
    359 1427.589456374018 run time = 9.180160999298096 seconds
    initial tour length 7877.340837481888
    360 1451.7227961908593 run time = 9.07239294052124 seconds
    initial tour length 8356.337246778174
    361 1358.077659899088 run time = 9.038307189941406 seconds
    initial tour length 8021.382189967824
    362 1411.8356044692378 run time = 9.093167781829834 seconds
    initial tour length 7718.727711195324
    363 1374.3372715818502 run time = 9.100759267807007 seconds
    initial tour length 7142.534151659751
    364 1462.5203114409135 run time = 9.149807929992676 seconds
    initial tour length 8206.581275491026
    365 1413.2823754023352 run time = 9.169795751571655 seconds
    initial tour length 7501.586068483358
    366 1495.8691836904347 run time = 9.035634279251099 seconds
    initial tour length 8232.554617556483
    367 1463.9957858986652 run time = 9.156904935836792 seconds
    initial tour length 8187.960737633859
    368 1436.8531214485945 run time = 9.084053039550781 seconds
    initial tour length 7635.861605744876
    369 1412.995623285419 run time = 9.227823972702026 seconds
    initial tour length 7507.9408743696795
    370 1452.2301905360762 run time = 9.168381214141846 seconds
    initial tour length 7661.4694687815045
    371 1494.1781861563618 run time = 9.491209030151367 seconds
    initial tour length 8214.427353943487
    372 1416.4761878839695 run time = 9.357002019882202 seconds
    initial tour length 8471.540690165008
    373 1486.4484043252385 run time = 9.442511081695557 seconds
    initial tour length 7503.520208580614
    374 1390.2748789161662 run time = 9.351598024368286 seconds
    initial tour length 7099.478170722621
    375 1394.784294687087 run time = 9.23297905921936 seconds
    initial tour length 7688.8817913925295
    376 1420.5438443077383 run time = 9.376341342926025 seconds
    initial tour length 7092.40564382763
    377 1360.7957181986 run time = 9.330818176269531 seconds
    initial tour length 7295.595969266611
    378 1528.4000438255055 run time = 9.36344289779663 seconds
    initial tour length 7886.644266616367
    379 1437.5046946854336 run time = 9.316551923751831 seconds
    initial tour length 8212.463502679731
    380 1411.711347901494 run time = 9.444299936294556 seconds
    initial tour length 8411.338020183293
    381 1364.569209178003 run time = 9.432449102401733 seconds
    initial tour length 7148.667110854369
    382 1404.219176265434 run time = 9.364936113357544 seconds
    initial tour length 6934.545353649787
    383 1417.6241315963855 run time = 9.122328996658325 seconds
    initial tour length 8201.91123079156
    384 1413.8966230432445 run time = 9.125101804733276 seconds
    initial tour length 7922.98001877857
    385 1472.5077432994929 run time = 9.16696310043335 seconds
    initial tour length 7435.9587138300585
    386 1413.0380587315078 run time = 9.064624786376953 seconds
    initial tour length 8146.355530292416
    387 1466.6362214792866 run time = 9.085830926895142 seconds
    initial tour length 7381.185932237429
    388 1447.4090799346654 run time = 9.070998907089233 seconds
    initial tour length 8159.611642812688
    389 1467.206034721076 run time = 9.15330982208252 seconds
    initial tour length 7986.922524644098
    390 1432.779165269833 run time = 9.216772079467773 seconds
    initial tour length 8869.131300093351
    391 1414.6449691968546 run time = 9.191828966140747 seconds
    initial tour length 7496.240749924432
    392 1518.7154849063138 run time = 9.115927934646606 seconds
    initial tour length 8232.93271741594
    393 1406.415422555027 run time = 9.066529989242554 seconds
    initial tour length 7823.129610697414
    394 1420.004951771737 run time = 9.11634612083435 seconds
    initial tour length 8617.02695597186
    395 1462.2322116928267 run time = 9.215687274932861 seconds
    initial tour length 8040.353877698184
    396 1444.2508590200289 run time = 9.33739185333252 seconds
    initial tour length 7764.634581292672
    397 1467.1783563738245 run time = 9.06824779510498 seconds
    initial tour length 8643.551674364075
    398 1395.955192396648 run time = 9.073969841003418 seconds
    initial tour length 7236.027974076593
    399 1456.3727277457392 run time = 9.179033994674683 seconds
    initial tour length 6959.0883495309845
    400 1502.0770615661274 run time = 9.03938102722168 seconds
    initial tour length 8480.020631353555
    401 1393.0652678423248 run time = 9.130134105682373 seconds
    initial tour length 7638.827880917408
    402 1458.6851741076887 run time = 9.101269006729126 seconds
    initial tour length 8088.4196775499095
    403 1454.6292228620803 run time = 9.090312004089355 seconds
    initial tour length 7395.288388874012
    404 1441.252172028117 run time = 9.056449890136719 seconds
    initial tour length 8441.74081887722
    405 1440.541839473169 run time = 9.033386945724487 seconds
    initial tour length 8362.59158078392
    406 1403.3852242412906 run time = 9.040621042251587 seconds
    initial tour length 7932.817403168885
    407 1430.639277815211 run time = 9.043375968933105 seconds
    initial tour length 7652.434971144055
    408 1425.8624420435444 run time = 9.018150091171265 seconds
    initial tour length 8218.029142435364
    409 1331.439177819865 run time = 9.027949810028076 seconds
    initial tour length 7452.53430131417
    410 1454.5123090460468 run time = 9.00142502784729 seconds
    initial tour length 8151.532499810508
    411 1498.0331366274536 run time = 9.164254903793335 seconds
    initial tour length 7882.484253610241
    412 1395.438660054031 run time = 9.093116044998169 seconds
    initial tour length 8330.646590651086
    413 1495.4398053079258 run time = 9.101282835006714 seconds
    initial tour length 8333.604092602598
    414 1526.763428406222 run time = 9.22003698348999 seconds
    initial tour length 7775.858890205591
    415 1409.2903268174778 run time = 9.121963024139404 seconds
    initial tour length 8243.809873877446
    416 1423.6405051767367 run time = 9.097348928451538 seconds
    initial tour length 8111.315518653412
    417 1508.704909598596 run time = 9.102114915847778 seconds
    initial tour length 7896.972293546651
    418 1488.9996586599818 run time = 9.050987005233765 seconds
    initial tour length 7542.685654405792
    419 1405.2244861699123 run time = 9.118211030960083 seconds
    initial tour length 7932.777703660223
    420 1409.3220875091104 run time = 9.117954969406128 seconds
    initial tour length 7704.935996960328
    421 1503.3301714418174 run time = 9.116252899169922 seconds
    initial tour length 7815.268216496274
    422 1412.4661154009293 run time = 9.088356018066406 seconds
    initial tour length 7670.331122463718
    423 1374.7108862155064 run time = 9.087466955184937 seconds
    initial tour length 8005.151248647207
    424 1501.3746824901923 run time = 9.16415286064148 seconds
    initial tour length 8407.015684428761
    425 1489.2293070621954 run time = 9.239236831665039 seconds
    initial tour length 8057.212924186434
    426 1476.7133730482835 run time = 9.060969829559326 seconds
    initial tour length 7805.6346713037465
    427 1414.3551981892672 run time = 9.058650970458984 seconds
    initial tour length 8143.659334497242
    428 1436.3254034099264 run time = 9.271182775497437 seconds
    initial tour length 8264.226518055066
    429 1426.040502690328 run time = 9.135354042053223 seconds
    initial tour length 8095.241980931108
    430 1405.9263294470675 run time = 9.07362699508667 seconds
    initial tour length 7751.003513248837
    431 1414.5262329486459 run time = 9.011610984802246 seconds
    initial tour length 7491.352592082456
    432 1481.8428909695353 run time = 9.113985061645508 seconds
    initial tour length 7313.304160040046
    433 1360.179818382244 run time = 9.202690839767456 seconds
    initial tour length 7454.130915503829
    434 1437.4906611336921 run time = 9.111674070358276 seconds
    initial tour length 8153.150298565611
    435 1381.7057720077971 run time = 9.014137029647827 seconds
    initial tour length 8306.361962215387
    436 1467.4404911069073 run time = 9.05799412727356 seconds
    initial tour length 8331.645553881108
    437 1435.4989592734935 run time = 9.132200241088867 seconds
    initial tour length 7685.32754755939
    438 1395.251354824706 run time = 8.998414039611816 seconds
    initial tour length 7996.6287120543275
    439 1408.6093845256135 run time = 9.033678770065308 seconds
    initial tour length 7864.614344274235
    440 1407.8502341346086 run time = 9.149302959442139 seconds
    initial tour length 7919.266216517395
    441 1410.7631626951513 run time = 9.0329110622406 seconds
    initial tour length 7797.994190845601
    442 1484.7187144774255 run time = 9.126405715942383 seconds
    initial tour length 8229.298489639938
    443 1401.988339742072 run time = 9.14852786064148 seconds
    initial tour length 8804.302123406265
    444 1469.4116549264559 run time = 9.047833681106567 seconds
    initial tour length 8269.832490244742
    445 1452.7279278968886 run time = 9.418541669845581 seconds
    initial tour length 7576.164350503364
    446 1440.9039868055975 run time = 9.24954080581665 seconds
    initial tour length 7990.677324439008
    447 1415.4738014099105 run time = 9.239958047866821 seconds
    initial tour length 7704.757965920146
    448 1413.9476538445315 run time = 9.128715991973877 seconds
    initial tour length 8390.350411839207
    449 1385.5610105561025 run time = 9.105767965316772 seconds
    initial tour length 7776.0370623496765
    450 1423.3063245729102 run time = 9.01808786392212 seconds
    initial tour length 7078.299594902681
    451 1397.646573798794 run time = 9.03642988204956 seconds
    initial tour length 8364.530768742174
    452 1529.4996415153057 run time = 9.007285833358765 seconds
    initial tour length 8183.578832349224
    453 1398.5828574370798 run time = 9.131580352783203 seconds
    initial tour length 8169.803054698571
    454 1472.6186720145665 run time = 9.150849103927612 seconds
    initial tour length 7820.547432400665
    455 1400.8475475330292 run time = 9.1385338306427 seconds
    initial tour length 8185.790157307341
    456 1536.3097425048772 run time = 9.113992929458618 seconds
    initial tour length 7650.119988699352
    457 1362.0686377479658 run time = 9.075179815292358 seconds
    initial tour length 7589.892463370214
    458 1372.8136627892893 run time = 9.120976209640503 seconds
    initial tour length 7853.659015019816
    459 1403.1090854348668 run time = 9.149140119552612 seconds
    initial tour length 8838.282696085113
    460 1411.3872812062125 run time = 9.052266120910645 seconds
    initial tour length 7371.895666883305
    461 1478.985134441363 run time = 9.161975860595703 seconds
    initial tour length 8356.123559507292
    462 1458.4778313505806 run time = 9.084043979644775 seconds
    initial tour length 7414.135851654224
    463 1455.0405344124272 run time = 9.060179948806763 seconds
    initial tour length 7441.014769387055
    464 1493.8395814648143 run time = 9.052051067352295 seconds
    initial tour length 8213.547409446897
    465 1383.0587255355417 run time = 9.095537900924683 seconds
    initial tour length 7479.601332663648
    466 1430.7745811166444 run time = 8.988700866699219 seconds
    initial tour length 7292.991434424379
    467 1432.8132679215973 run time = 9.005064249038696 seconds
    initial tour length 8059.787491061309
    468 1415.0517709543942 run time = 9.045820951461792 seconds
    initial tour length 8070.7086600237935
    469 1409.7607737288947 run time = 9.096420049667358 seconds
    initial tour length 6940.81717010837
    470 1483.2227969864725 run time = 9.11384129524231 seconds
    initial tour length 7720.553202342618
    471 1515.684643541338 run time = 9.148412942886353 seconds
    initial tour length 8100.932944155947
    472 1353.3490041340256 run time = 9.172917127609253 seconds
    initial tour length 8492.663277246684
    473 1410.9811565944954 run time = 9.230379819869995 seconds
    initial tour length 7685.329593475329
    474 1464.323287740004 run time = 9.162314891815186 seconds
    initial tour length 7840.192697540726
    475 1433.3004906926037 run time = 9.146744012832642 seconds
    initial tour length 7292.718649231732
    476 1388.3604185920985 run time = 9.219252109527588 seconds
    initial tour length 7333.202673622944
    477 1421.8116550890006 run time = 9.113986015319824 seconds
    initial tour length 7673.32771133805
    478 1423.55432332404 run time = 9.29775094985962 seconds
    initial tour length 7889.641681177289
    479 1470.7034233918896 run time = 9.111745119094849 seconds
    initial tour length 7702.994536096894
    480 1402.670339675265 run time = 9.156280994415283 seconds
    initial tour length 8545.859356537147
    481 1440.322940571198 run time = 9.048450946807861 seconds
    initial tour length 7793.6858629999315
    482 1409.6730431451424 run time = 8.990499019622803 seconds
    initial tour length 8431.567567820306
    483 1499.4831775291204 run time = 9.086676836013794 seconds
    initial tour length 7587.909860029977
    484 1501.5558066961437 run time = 9.180746793746948 seconds
    initial tour length 7640.968266044295
    485 1465.0755326805447 run time = 9.094740867614746 seconds
    initial tour length 7815.315059559207
    486 1439.768431643822 run time = 9.104137897491455 seconds
    initial tour length 7800.133661041185
    487 1424.77316824114 run time = 9.108681917190552 seconds
    initial tour length 7334.88305135165
    488 1450.4948190536622 run time = 9.12662935256958 seconds
    initial tour length 8231.25426890832
    489 1425.5633838661959 run time = 8.988035917282104 seconds
    initial tour length 8581.038724817512
    490 1368.842395556815 run time = 9.077831268310547 seconds
    initial tour length 8253.886304083322
    491 1371.0448919660128 run time = 9.073930978775024 seconds
    initial tour length 8213.727585310007
    492 1355.065283422502 run time = 9.045557022094727 seconds
    initial tour length 7103.921061798691
    493 1354.8880961661412 run time = 9.165971994400024 seconds
    initial tour length 7764.128563122271
    494 1449.4437988703917 run time = 8.9828360080719 seconds
    initial tour length 7519.640474403262
    495 1461.9557487885868 run time = 9.1613130569458 seconds
    initial tour length 6893.607579437456
    496 1455.283078395797 run time = 9.141161918640137 seconds
    initial tour length 7796.559394276331
    497 1399.6738697367118 run time = 9.004340171813965 seconds
    initial tour length 7128.061168775776
    498 1396.2493903740426 run time = 9.124077796936035 seconds
    initial tour length 7335.561112700709
    499 1357.3562142901217 run time = 9.21147608757019 seconds



```python
plot_tour(super_optimal_tour)
tour_length = determine_tour_length(super_optimal_tour)
print(tour_length)
```


![png](output_22_0.png)


    1331.439177819865


This tour is below the optimal bound suggested by HK, and has a bit of a fish-centaur look to it, so it's probably very very close to optimal. Each of the combined runs takes about 9 seconds, so the 500 runs took about the same time as a single SA run with the full 200 temperature steps.



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
